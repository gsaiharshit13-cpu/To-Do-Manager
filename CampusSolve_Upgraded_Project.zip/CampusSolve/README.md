# CampusSolve – Smart To-Do List Manager

A responsive student productivity website powered by Python Flask and local JSON storage.

## Requirements
- Python 3.10 or newer
- pip

## Run on Windows
1. Extract the ZIP file.
2. Open the `CampusSolve` folder in VS Code.
3. Open Terminal in that folder.
4. Run:

```bash
py -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
py app.py
```

5. Open **http://127.0.0.1:5000** in your browser.

## Run on macOS / Linux

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

## Features
- Create, edit, delete and complete tasks
- Search by title/description
- Filter by status, category and priority
- Deadline and overdue indicators
- Analytics dashboard and executive summary
- JSON and CSV export
- CSV import with row-level validation feedback
- JSON persistence in `data/tasks.json`
- Corrupt JSON/schema recovery: the original damaged file is preserved with a timestamped backup name and a fresh data file is initialized
- Rotating application logs in `logs/campussolve.log`
- Health/status endpoint at `/api/health`
- Upcoming-deadline analytics (tasks due within three days) and productivity score
- Automated unit tests for validation, storage recovery, and analytics

## Run automated tests

From the `CampusSolve` folder (with the virtual environment activated):

```bash
python -m unittest discover -s tests -v
```

The test suite covers task validation, JSON save/load, corrupt-file backup and recovery, analytics calculations, and Flask API routes. The API integration tests require Flask from `requirements.txt`; storage, validation, and analytics tests can run without the server.

## Logging and diagnostics

Application events and errors are written to `logs/campussolve.log`. The log rotates automatically to keep a few recent backups. Open `http://127.0.0.1:5000/api/health` to check the local server and task-store status.

## CSV import format
Required column: `title`. Optional columns: `description`, `category`, `priority`, `due_date`, `status`.

Example header:

```csv
title,description,category,priority,due_date,status
Finish DBMS assignment,Normalization exercises,Assignment,High,2026-11-20,Pending
Revise calculus,Practice integration,Study,Medium,2026-11-18,Completed
```

## Hackathon demo flow
1. Add a task with a title, category, priority and deadline.
2. Try submitting an empty title to demonstrate validation.
3. Mark a task complete and show the dashboard counters update.
4. Search and filter tasks.
5. Open Analytics to show completion rate, overdue count and category breakdown.
6. Export CSV/JSON or import the sample CSV.
7. Stop the server with `Ctrl+C`, restart it, and show that tasks persist.

## Project structure

```text
CampusSolve/
├── app.py
├── requirements.txt
├── README.md
├── analytics.py
├── storage.py
├── validation.py
├── tests/
│   ├── test_analytics.py
│   ├── test_storage.py
│   └── test_validation.py
├── logs/ (created automatically)
├── data/
│   └── tasks.json
├── sample_data/
│   ├── sample_tasks.csv
│   └── sample_tasks.json
├── static/
│   ├── app.js
│   └── style.css
└── templates/
    └── index.html
```

This is a local development/demo application. The Flask debugger is disabled by default. For public deployment, add authentication, CSRF protection, rate limiting, a production WSGI server, and a database such as SQLite or PostgreSQL. The JSON store is appropriate for a small student demo, not concurrent multi-user production traffic.
