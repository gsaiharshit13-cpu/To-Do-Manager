"""Reliable JSON persistence for CampusSolve tasks."""
import json
import logging
import os
import tempfile
from datetime import datetime
from pathlib import Path

logger = logging.getLogger(__name__)
DEFAULT_DATA_FILE = Path(__file__).parent / "data" / "tasks.json"


class StorageError(RuntimeError):
    """Raised when task data cannot safely be read or written."""


def _valid_records(data):
    if not isinstance(data, list):
        return False
    for item in data:
        if not isinstance(item, dict) or not item.get("id") or not item.get("title"):
            return False
    return True


def load_tasks(path=None):
    data_file = Path(path or DEFAULT_DATA_FILE)
    data_file.parent.mkdir(parents=True, exist_ok=True)
    if not data_file.exists():
        save_tasks([], data_file)
        return []

    try:
        data = json.loads(data_file.read_text(encoding="utf-8"))
        if not _valid_records(data):
            raise ValueError("JSON file does not contain a valid task list/schema")
        return data
    except (json.JSONDecodeError, UnicodeDecodeError, ValueError) as exc:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        backup = data_file.with_name(f"{data_file.stem}.corrupt_{stamp}{data_file.suffix}")
        try:
            os.replace(data_file, backup)
            logger.error("Task data was invalid. Preserved original at %s; starting with an empty list. Reason: %s", backup, exc)
            save_tasks([], data_file)
            return []
        except OSError as backup_exc:
            logger.exception("Could not preserve corrupted task data at %s", data_file)
            raise StorageError(f"Task data is damaged and could not be backed up: {backup_exc}") from backup_exc
    except OSError as exc:
        logger.exception("Could not read task data from %s", data_file)
        raise StorageError(f"Could not read task data: {exc}") from exc


def save_tasks(tasks, path=None):
    data_file = Path(path or DEFAULT_DATA_FILE)
    if not _valid_records(tasks):
        raise StorageError("Refusing to save invalid task data.")
    data_file.parent.mkdir(parents=True, exist_ok=True)
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=data_file.parent,
                                         prefix=data_file.name + ".", suffix=".tmp", delete=False) as temp:
            temp_path = Path(temp.name)
            json.dump(tasks, temp, indent=2, ensure_ascii=False)
            temp.flush()
            os.fsync(temp.fileno())
        os.replace(temp_path, data_file)
    except OSError as exc:
        logger.exception("Could not save task data to %s", data_file)
        if temp_path and temp_path.exists():
            try:
                temp_path.unlink()
            except OSError:
                logger.warning("Could not remove temporary file %s", temp_path)
        raise StorageError(f"Could not save task data: {exc}") from exc
