"""CampusSolve Flask application."""
import csv
import io
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime
from pathlib import Path
import uuid

from flask import Flask, Response, jsonify, render_template, request, send_file

from analytics import build_report
from storage import DEFAULT_DATA_FILE, StorageError, load_tasks, save_tasks
from validation import ValidationError, validate_task

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
DATA_FILE = DEFAULT_DATA_FILE

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024  # 2 MB upload/request limit


def configure_logging():
    log_dir = BASE_DIR / "logs"
    log_dir.mkdir(exist_ok=True)
    handler = RotatingFileHandler(log_dir / "campussolve.log", maxBytes=500_000, backupCount=3, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    handler.setLevel(logging.INFO)
    if not any(isinstance(h, RotatingFileHandler) for h in app.logger.handlers):
        app.logger.addHandler(handler)
    app.logger.setLevel(logging.INFO)


configure_logging()


def _load():
    return load_tasks(DATA_FILE)


def _save(tasks):
    save_tasks(tasks, DATA_FILE)


def _json_payload():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        raise ValidationError("Send task details as a valid JSON object.")
    return payload


@app.errorhandler(StorageError)
def handle_storage_error(error):
    app.logger.error("Storage operation failed: %s", error)
    return jsonify({"error": str(error)}), 500


@app.errorhandler(413)
def file_too_large(_error):
    return jsonify({"error": "The uploaded file is too large. Maximum size is 2 MB."}), 413


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/api/tasks")
def get_tasks():
    return jsonify(_load())


@app.post("/api/tasks")
def add_task():
    try:
        task = validate_task(_json_payload())
        now = datetime.now().isoformat(timespec="seconds")
        task.update({"id": str(uuid.uuid4()), "created_at": now,
                     "completed_at": now if task["status"] == "Completed" else ""})
        tasks = _load()
        tasks.insert(0, task)
        _save(tasks)
        app.logger.info("Task created: %s", task["id"])
        return jsonify(task), 201
    except ValidationError as error:
        return jsonify({"error": str(error)}), 400


@app.put("/api/tasks/<task_id>")
def update_task(task_id):
    try:
        incoming = validate_task(_json_payload())
        tasks = _load()
        for task in tasks:
            if task["id"] == task_id:
                old_status = task.get("status")
                task.update(incoming)
                if incoming["status"] == "Completed" and old_status != "Completed":
                    task["completed_at"] = datetime.now().isoformat(timespec="seconds")
                elif incoming["status"] == "Pending":
                    task["completed_at"] = ""
                _save(tasks)
                app.logger.info("Task updated: %s", task_id)
                return jsonify(task)
        return jsonify({"error": "Task not found."}), 404
    except ValidationError as error:
        return jsonify({"error": str(error)}), 400


@app.patch("/api/tasks/<task_id>/complete")
def complete_task(task_id):
    tasks = _load()
    for task in tasks:
        if task["id"] == task_id:
            task["status"] = "Completed" if task.get("status") != "Completed" else "Pending"
            task["completed_at"] = datetime.now().isoformat(timespec="seconds") if task["status"] == "Completed" else ""
            _save(tasks)
            app.logger.info("Task status changed: %s -> %s", task_id, task["status"])
            return jsonify(task)
    return jsonify({"error": "Task not found."}), 404


@app.delete("/api/tasks/<task_id>")
def delete_task(task_id):
    tasks = _load()
    updated = [task for task in tasks if task["id"] != task_id]
    if len(updated) == len(tasks):
        return jsonify({"error": "Task not found."}), 404
    _save(updated)
    app.logger.info("Task deleted: %s", task_id)
    return jsonify({"success": True})


@app.get("/api/export/<kind>")
def export_tasks(kind):
    tasks = _load()
    if kind == "json":
        return send_file(DATA_FILE, as_attachment=True, download_name="campussolve_tasks.json", mimetype="application/json")
    if kind == "csv":
        output = io.StringIO(newline="")
        fields = ["id", "title", "description", "category", "priority", "due_date", "status", "created_at", "completed_at"]
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        writer.writerows(tasks)
        return Response(output.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": "attachment; filename=campussolve_tasks.csv"})
    return jsonify({"error": "Unsupported export format."}), 400


@app.post("/api/import")
def import_csv():
    if "file" not in request.files:
        return jsonify({"error": "Choose a CSV file first."}), 400
    file = request.files["file"]
    if not file.filename or not file.filename.lower().endswith(".csv"):
        return jsonify({"error": "Only .csv files are supported."}), 400
    try:
        content = file.stream.read().decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(content))
        if not reader.fieldnames or "title" not in reader.fieldnames:
            return jsonify({"error": "CSV must contain a title column."}), 400
        tasks, errors, added = _load(), [], 0
        for row_num, row in enumerate(reader, start=2):
            if row_num > 1001:
                errors.append({"row": row_num, "error": "Import limit is 1,000 rows per file."})
                break
            try:
                item = validate_task(row)
                now = datetime.now().isoformat(timespec="seconds")
                item.update({"id": str(uuid.uuid4()), "created_at": now,
                             "completed_at": now if item["status"] == "Completed" else ""})
                tasks.insert(0, item)
                added += 1
            except ValidationError as error:
                errors.append({"row": row_num, "error": str(error)})
        _save(tasks)
        app.logger.info("CSV import completed: %d added, %d invalid rows", added, len(errors))
        return jsonify({"added": added, "errors": errors})
    except UnicodeDecodeError:
        return jsonify({"error": "CSV must be UTF-8 encoded."}), 400
    except csv.Error as error:
        app.logger.warning("CSV import parsing failed: %s", error)
        return jsonify({"error": "The CSV file could not be parsed."}), 400


@app.get("/api/report")
def report():
    return jsonify(build_report(_load()))


@app.get("/api/health")
def health():
    """Simple operational status endpoint for demo and troubleshooting."""
    return jsonify({"status": "ok", "storage": "json", "task_count": len(_load()),
                    "log_file": "logs/campussolve.log"})


if __name__ == "__main__":
    # Debug mode is opt-in; do not expose the interactive debugger by default.
    app.run(host="127.0.0.1", port=5000, debug=False)
