import json
import tempfile
import unittest
from pathlib import Path
from storage import StorageError, load_tasks, save_tasks


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.file = Path(self.temp_dir.name) / "tasks.json"

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_save_and_load_round_trip(self):
        tasks = [{"id": "1", "title": "Test task", "status": "Pending"}]
        save_tasks(tasks, self.file)
        self.assertEqual(load_tasks(self.file), tasks)

    def test_missing_file_creates_empty_store(self):
        self.assertEqual(load_tasks(self.file), [])
        self.assertTrue(self.file.exists())

    def test_corrupt_json_is_backed_up_and_recovered(self):
        self.file.write_text("{broken json", encoding="utf-8")
        self.assertEqual(load_tasks(self.file), [])
        backups = list(self.file.parent.glob("tasks.corrupt_*.json"))
        self.assertEqual(len(backups), 1)
        self.assertEqual(backups[0].read_text(encoding="utf-8"), "{broken json")
        self.assertEqual(json.loads(self.file.read_text(encoding="utf-8")), [])

    def test_invalid_schema_is_backed_up(self):
        self.file.write_text(json.dumps({"not": "a list"}), encoding="utf-8")
        self.assertEqual(load_tasks(self.file), [])
        self.assertEqual(len(list(self.file.parent.glob("tasks.corrupt_*.json"))), 1)

    def test_invalid_data_is_not_saved(self):
        with self.assertRaises(StorageError):
            save_tasks([{"title": "Missing ID"}], self.file)


if __name__ == "__main__":
    unittest.main()
