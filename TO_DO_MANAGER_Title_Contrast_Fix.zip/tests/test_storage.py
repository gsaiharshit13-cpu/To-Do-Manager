import json
import tempfile
import unittest
from pathlib import Path
from storage import configure_database, load_tasks, save_tasks, create_task, update_task, delete_task, migrate_json_once, list_tasks_paginated

class StorageTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db = Path(self.temp_dir.name) / "tasks.db"
        configure_database(f"sqlite:///{self.db.as_posix()}")

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_save_and_load_round_trip(self):
        tasks = [{"id":"1","title":"Test task","status":"Pending","description":"","category":"Study","priority":"High","due_date":"","created_at":"","completed_at":""}]
        save_tasks(tasks)
        self.assertEqual(load_tasks(), tasks)

    def test_create_update_delete(self):
        item = {"id":"2","title":"Created","status":"Pending"}
        create_task(item)
        updated = update_task("2", {"title":"Updated"})
        self.assertEqual(updated["title"], "Updated")
        self.assertTrue(delete_task("2"))
        self.assertFalse(delete_task("2"))
        self.assertEqual(load_tasks(), [])

    def test_json_migration_keeps_original(self):
        legacy = Path(self.temp_dir.name) / "legacy.json"
        legacy.write_text(json.dumps([{"id":"old","title":"Legacy task","status":"Pending"}]), encoding="utf-8")
        self.assertEqual(migrate_json_once(legacy), 1)
        self.assertEqual(load_tasks()[0]["title"], "Legacy task")
        self.assertTrue(legacy.exists())

    def test_server_side_pagination_and_filters(self):
        items = []
        for n in range(23):
            items.append({"id":str(n),"title":f"Study task {n}","description":"revision",
                          "category":"Study","priority":"High" if n % 2 == 0 else "Low",
                          "due_date":"","status":"Pending","created_at":f"2026-11-{(n%28)+1:02d}","completed_at":""})
        save_tasks(items)
        first = list_tasks_paginated(page=1, per_page=10, priority="High")
        second = list_tasks_paginated(page=2, per_page=10, priority="High")
        self.assertEqual(first["total"], 12)
        self.assertEqual(len(first["items"]), 10)
        self.assertEqual(len(second["items"]), 2)
        self.assertEqual(first["pages"], 2)
        self.assertTrue(all(x["priority"] == "High" for x in first["items"]))

if __name__ == "__main__":
    unittest.main()
