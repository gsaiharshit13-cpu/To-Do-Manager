"""Create initial CampusSolve task schema."""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import inspect

revision = "0001_initial"
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    bind = op.get_bind()
    if not inspect(bind).has_table("tasks"):
        op.create_table(
        "tasks",
        sa.Column("id", sa.String(length=64), primary_key=True),
        sa.Column("title", sa.String(length=100), nullable=False),
        sa.Column("description", sa.String(length=500), nullable=False, server_default=""),
        sa.Column("category", sa.String(length=40), nullable=False, server_default="Personal"),
        sa.Column("priority", sa.String(length=10), nullable=False, server_default="Medium"),
        sa.Column("due_date", sa.String(length=10), nullable=False, server_default=""),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="Pending"),
        sa.Column("created_at", sa.String(length=32), nullable=False, server_default=""),
        sa.Column("completed_at", sa.String(length=32), nullable=False, server_default=""),
    )
    names = {item["name"] for item in inspect(bind).get_indexes("tasks")} if inspect(bind).has_table("tasks") else set()
    if "ix_tasks_status_priority" not in names: op.create_index("ix_tasks_status_priority", "tasks", ["status", "priority"])
    if "ix_tasks_due_date" not in names: op.create_index("ix_tasks_due_date", "tasks", ["due_date"])
    if "ix_tasks_category" not in names: op.create_index("ix_tasks_category", "tasks", ["category"])

def downgrade():
    bind = op.get_bind()
    if inspect(bind).has_table("tasks"):
        names = {item["name"] for item in inspect(bind).get_indexes("tasks")}
        for name in ("ix_tasks_category", "ix_tasks_due_date", "ix_tasks_status_priority"):
            if name in names: op.drop_index(name, table_name="tasks")
        op.drop_table("tasks")
