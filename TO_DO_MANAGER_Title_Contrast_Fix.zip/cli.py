"""Optional terminal interface for the original CLI-oriented CampusSolve brief."""
import uuid
import os
from dotenv import load_dotenv
import csv
from pathlib import Path
from datetime import datetime
from storage import load_tasks, create_task, update_task, delete_task, configure_database, migrate_json_once

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")
DB_PATH = Path(os.getenv("DATABASE_PATH", str(BASE_DIR / "data" / "campussolve.db")))
DB_URL = os.getenv("DATABASE_URL") or f"sqlite:///{DB_PATH.as_posix()}"
configure_database(DB_URL)
migrate_json_once(Path(os.getenv("LEGACY_JSON_PATH", str(BASE_DIR / "data" / "tasks.json"))))
from validation import validate_task, ValidationError


def show_tasks():
    tasks = load_tasks()
    if not tasks:
        print("No tasks yet.")
        return
    for i, task in enumerate(tasks, 1):
        mark = "✓" if task["status"] == "Completed" else " "
        print(f"{i}. [{mark}] {task['title']} | {task['priority']} | {task['category']} | {task['status']} | ID: {task['id']}")


def add_task():
    payload = {"title": input("Title: "), "description": input("Description: "),
               "category": input("Category [Personal]: ") or "Personal",
               "priority": input("Priority [Low/Medium/High, default Medium]: ") or "Medium",
               "due_date": input("Due date YYYY-MM-DD [optional]: ")}
    try:
        item = validate_task(payload)
        now = datetime.now().isoformat(timespec="seconds")
        item.update({"id": str(uuid.uuid4()), "created_at": now, "completed_at": ""})
        create_task(item)
        print("Task added successfully.")
    except ValidationError as exc:
        print(f"Input error: {exc}")


def complete_task():
    task_id = input("Task ID to mark complete: ").strip()
    task = next((x for x in load_tasks() if x["id"] == task_id), None)
    if not task:
        print("Task not found.")
        return
    now = datetime.now().isoformat(timespec="seconds")
    update_task(task_id, {"status": "Completed", "completed_at": now})
    print("Task marked complete.")


def search_tasks():
    term = input("Search title/description: ").strip().casefold()
    matches = [t for t in load_tasks() if term in (t["title"] + " " + t["description"]).casefold()]
    for task in matches:
        print(f"- {task['title']} [{task['status']}] ({task['id']})")
    if not matches:
        print("No matching tasks.")


def export_csv():
    tasks = load_tasks()
    target = Path("campussolve_report.csv")
    fields = ["id", "title", "description", "category", "priority", "due_date", "status", "created_at", "completed_at"]
    with target.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(tasks)
    print(f"Exported {len(tasks)} task(s) to {target.resolve()}")


def show_summary():
    tasks = load_tasks()
    completed = sum(t["status"] == "Completed" for t in tasks)
    pending = len(tasks) - completed
    print(f"Total: {len(tasks)} | Completed: {completed} | Pending: {pending}")


def main():
    actions = {"1": show_tasks, "2": add_task, "3": complete_task, "4": search_tasks, "6": show_summary, "7": export_csv}
    while True:
        print("\nCampusSolve CLI | 1 List  2 Add  3 Complete  4 Search  5 Delete  6 Summary  7 Export CSV  0 Exit")
        choice = input("Choose: ").strip()
        if choice == "0":
            print("Goodbye!")
            break
        if choice == "5":
            task_id = input("Task ID to delete: ").strip()
            print("Deleted." if delete_task(task_id) else "Task not found.")
        elif choice in actions:
            actions[choice]()
        else:
            print("Choose a valid menu option (0-7).")


if __name__ == "__main__":
    main()
