# TO DO MANAGER — Styled Streamlit App

## Run on Windows
Open this folder in VS Code, then in the terminal run:

```powershell
py -m pip install -r requirements.txt
py -m streamlit run streamlit_app.py
```

Open http://localhost:8501.

This version uses a modern purple-and-white dashboard inspired by the supplied reference screenshot. It uses SQLite for persistent tasks and does not require pandas.
