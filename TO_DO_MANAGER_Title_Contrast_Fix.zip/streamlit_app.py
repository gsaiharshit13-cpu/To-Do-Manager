"""CampusSolve — Streamlit student productivity workspace."""
from pathlib import Path
from datetime import datetime, date
import csv, io, json, uuid, html

import streamlit as st
import storage
from validation import validate_task, ValidationError
from analytics import build_report

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
storage.configure_database(f"sqlite:///{(DATA_DIR / 'campussolve_streamlit.db').as_posix()}")

st.set_page_config(page_title="TO DO MANAGER | Student Workspace", page_icon="🎓", layout="wide")

st.markdown("""
<style>
:root {
  --ink:#202447; --muted:#7b82a4; --purple:#6c58ed; --purple-dark:#30245f;
  --line:#e9eaf4; --surface:#ffffff; --canvas:#f7f7fc;
}
html, body, [class*="css"] {font-family:Inter, ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;}
.stApp, [data-testid="stAppViewContainer"] {background:var(--canvas)!important;color:var(--ink)!important;}
[data-testid="stHeader"] {background:rgba(247,247,252,.96)!important;}
[data-testid="stSidebar"] {display:none;}
.block-container {max-width:1240px;padding-top:1.35rem;padding-bottom:3rem;}
/* Keep all native Streamlit text readable regardless of inherited theme. */
main .block-container, main .block-container p, main .block-container label,
main .block-container span, main .block-container h1, main .block-container h2,
main .block-container h3, main .block-container h4 {color:var(--ink);}
.brand-row {display:flex;align-items:center;gap:13px;margin:0 0 18px;}
.brand-mark {width:48px;height:48px;border-radius:15px;background:linear-gradient(145deg,#806aff,#5d49df);
display:flex;align-items:center;justify-content:center;color:#fff!important;font-size:25px;font-weight:800;
box-shadow:0 8px 20px #6957e633;}
.brand-name {font-size:1.55rem;font-weight:800;line-height:1.2;color:#171b37!important;}
.brand-sub {font-size:.68rem;letter-spacing:.22em;color:#8790b2!important;font-weight:700;margin-top:5px;}
.hero {position:relative;overflow:hidden;padding:30px 32px;border-radius:20px;
background:linear-gradient(110deg,#29204f 0%,#4c3c91 58%,#6652b8 100%);margin:18px 0 20px;
box-shadow:0 12px 30px #34266b18;}
.hero:after {content:"";position:absolute;width:390px;height:390px;border:1px solid #ffffff16;border-radius:50%;
right:100px;top:-220px;box-shadow:0 0 0 40px #ffffff08,0 0 0 85px #ffffff06;}
.hero-kicker {color:#c9c0ff!important;font-size:.68rem;letter-spacing:.2em;font-weight:800;margin-bottom:12px;}
.hero h1 {color:#fff!important;font-size:2rem!important;font-weight:800;margin:0 0 7px!important;position:relative;z-index:1;}
.hero p {color:#f0edff!important;margin:0!important;font-size:.95rem;position:relative;z-index:1;}
.hero-spark {position:absolute;right:28px;top:50px;color:#c4baff;font-size:38px;}
.section-kicker {font-size:.68rem;letter-spacing:.2em;color:#9299b7!important;font-weight:800;margin:6px 0 5px;}
.metric-card {background:#fff;border:1px solid #ececf5;border-radius:17px;padding:19px 20px;
min-height:132px;box-shadow:0 4px 14px #22234a05;}
.metric-label {color:#7c83a5!important;font-size:.82rem;margin-bottom:18px;}
.metric-value {color:#202447!important;font-size:2rem;font-weight:800;line-height:1;}
.metric-note {color:#9aa0ba!important;font-size:.72rem;margin-top:11px;}
.metric-icon {float:right;width:34px;height:34px;border-radius:11px;background:#f0edff;color:#705cf0!important;
display:flex;align-items:center;justify-content:center;font-weight:800;}
.task-card {background:#fff;border:1px solid #e9eaf4;border-radius:15px;padding:16px 18px;margin:10px 0;
box-shadow:0 4px 14px #22234a05;}
.task-title {font-size:1rem;font-weight:750;color:#202447!important;margin-bottom:6px;}
.task-meta {font-size:.78rem;color:#858ba9!important;line-height:1.6;}
.pill {display:inline-block;padding:4px 9px;border-radius:20px;font-size:.68rem;font-weight:750;background:#f0edff;color:#6552df!important;margin-right:5px;}
.pill-high {background:#fff0ed;color:#d45c45!important;}
.pill-done {background:#e8f8ef;color:#268653!important;}
div[data-testid="stMetric"] {background:#fff!important;border:1px solid var(--line);border-radius:16px;padding:17px;}
div[data-testid="stMetric"] label, div[data-testid="stMetric"] [data-testid="stMetricValue"] {color:var(--ink)!important;}
/* Form fields: explicitly force a light palette, including calendar and select controls. */
main input, main textarea, main [data-baseweb="select"]>div,
main [data-testid="stDateInput"] input, main [data-testid="stTextInput"] input,
main [data-testid="stTextArea"] textarea {
  background:#fff!important;color:#202447!important;border:1px solid #dfe1ef!important;
  border-radius:10px!important;box-shadow:none!important;color-scheme:light!important;
}
main input::placeholder, main textarea::placeholder {color:#9298b0!important;opacity:1!important;}
main [data-baseweb="select"] *, main [data-testid="stDateInput"] *,
main [data-testid="stDateInput"] button, main [data-testid="stDateInput"] svg {
  color:#303553!important;fill:#707797!important;
}
main [data-baseweb="select"]>div {min-height:44px!important;}
main [data-testid="stDateInput"] input {min-height:44px!important;}
main [data-testid="stForm"] {background:#fff!important;border:1px solid var(--line);border-radius:16px;padding:18px;}
/* Buttons including Streamlit form-submit buttons should never inherit the red default theme. */
main button[kind="primary"], main [data-testid="stFormSubmitButton"] button,
main [data-testid="stDownloadButton"] button {
  background:linear-gradient(135deg,#7662f4,#5f4add)!important;color:#fff!important;
  border:0!important;border-radius:11px!important;font-weight:700!important;
  min-height:42px;box-shadow:0 5px 14px #6c58ed26!important;
}
main button[kind="primary"] *, main [data-testid="stFormSubmitButton"] button *,
main [data-testid="stDownloadButton"] button * {color:#fff!important;fill:#fff!important;}
main button[kind="primary"]:hover, main [data-testid="stFormSubmitButton"] button:hover,
main [data-testid="stDownloadButton"] button:hover {background:#5140c7!important;transform:translateY(-1px);}
main button:not([kind="primary"]) {border-radius:10px!important;}
/* Expander header: clear white surface and dark, readable label. */
main [data-testid="stExpander"] {border:1px solid #e7e8f2!important;border-radius:14px;overflow:hidden;background:#fff!important;}
main [data-testid="stExpander"] details>summary {background:#fff!important;padding:14px 17px!important;}
main [data-testid="stExpander"] details>summary,
main [data-testid="stExpander"] details>summary p,
main [data-testid="stExpander"] details>summary span,
main [data-testid="stExpander"] details>summary svg {color:#272b4d!important;fill:#272b4d!important;font-weight:700;}
main [data-testid="stExpander"] details>div {background:#fff!important;}
div[role="radiogroup"] {gap:8px;}
div[role="radiogroup"] label {background:#fff;border:1px solid #e8e8f3;border-radius:11px;padding:8px 15px;}
div[role="radiogroup"] label[data-checked="true"] {background:#f0edff;border-color:#d9d2ff;}
.stProgress>div>div {background:#6c58ed!important;}
hr {border-color:#ececf4!important;}
small,.stCaption {color:#858ba9!important;}
/* Final contrast and border cleanup */
main .block-container .hero h1,
main .block-container .hero p,
main .block-container .hero .hero-kicker {color:#ffffff!important;}
main .block-container .hero .hero-kicker {color:#d2caff!important;}
main .block-container .brand-name {color:#202447!important;}
.brand-row .brand-name,
.brand-row .brand-name * {color:#202447!important;-webkit-text-fill-color:#202447!important;opacity:1!important;}
.hero h1, .hero h1 *,
.hero p, .hero p * {color:#ffffff!important;-webkit-text-fill-color:#ffffff!important;opacity:1!important;}

main [data-testid="stExpander"] {border:1px solid #e5e6f0!important;box-shadow:none!important;}
main [data-testid="stExpander"] details>summary {border:0!important;outline:0!important;}
main [data-testid="stExpander"] details>div {border-top:1px solid #ececf4!important;}
main hr {display:none!important;}
[data-testid="stDecoration"] {display:none!important;}
/* Mobile/tablet layout polish */
@media (max-width: 760px) {
  .block-container {padding-left:1rem;padding-right:1rem;}
  .hero {padding:23px 20px;}
  .hero h1 {font-size:1.65rem!important;}
  .metric-card {padding:15px;min-height:118px;}
}
</style>
""", unsafe_allow_html=True)

def esc(value):
    return html.escape(str(value or ""))

def load_tasks():
    return storage.load_tasks()

def rerun():
    st.rerun()

tasks = load_tasks()
report = build_report(tasks)

st.markdown("""
<div class="brand-row">
  <div class="brand-mark">✓</div>
  <div><div class="brand-name" style="color:#202447!important;opacity:1!important;-webkit-text-fill-color:#202447!important;">TO DO MANAGER</div><div class="brand-sub" style="color:#8790b2!important;opacity:1!important;-webkit-text-fill-color:#8790b2!important;">STUDENT WORKSPACE</div></div>
</div>
""", unsafe_allow_html=True)

page = st.radio("Workspace", ["My Tasks", "Analytics", "Import / Export"],
                horizontal=True, label_visibility="collapsed")
st.markdown("""
<div class="hero">
  <div class="hero-kicker">TO DO MANAGER DASHBOARD</div>
  <h1 style="color:#ffffff!important;opacity:1!important;-webkit-text-fill-color:#ffffff!important;text-shadow:0 1px 1px #211744;">Make today count.</h1>
  <p style="color:#f4f1ff!important;opacity:1!important;-webkit-text-fill-color:#f4f1ff!important;">Organize your workload, focus on what matters, and track your progress.</p>
  <div class="hero-spark">✦</div>
</div>
""", unsafe_allow_html=True)
st.caption(datetime.now().strftime("Today · %A, %d %B %Y"))

def metric_card(label, value, note, symbol):
    st.markdown(f"""<div class="metric-card">
      <div class="metric-icon">{symbol}</div>
      <div class="metric-label">{esc(label)}</div>
      <div class="metric-value">{esc(value)}</div>
      <div class="metric-note">{esc(note)}</div>
    </div>""", unsafe_allow_html=True)

if page == "My Tasks":
    cols = st.columns(4)
    metric_data = [
        ("Total tasks", report["total"], "All your tasks", "▤"),
        ("Completed", report["completed"], "Tasks finished", "✓"),
        ("In progress", report["pending"], "Still on your list", "◷"),
        ("Overdue", report["overdue"], "Need your attention", "!"),
    ]
    for col, data in zip(cols, metric_data):
        with col:
            metric_card(*data)

    st.markdown("### My Tasks")
    st.markdown('<div class="section-kicker">YOUR PERSONAL PRODUCTIVITY HUB</div>', unsafe_allow_html=True)
    with st.expander("＋  Add a new task", expanded=not bool(tasks)):
        with st.form("new_task", clear_on_submit=True):
            title = st.text_input("Task title *", max_chars=100, placeholder="e.g. Complete data structures assignment")
            desc = st.text_area("Description", max_chars=500, placeholder="Add details about this task...")
            c1, c2, c3 = st.columns(3)
            category = c1.selectbox("Category", ["Study", "Assignment", "Personal", "Project", "Exam", "Work", "Other"])
            priority = c2.selectbox("Priority", ["Low", "Medium", "High"], index=1)
            due = c3.date_input("Deadline", value=None)
            submitted = st.form_submit_button("＋ Add new task", type="primary")
            if submitted:
                try:
                    item = validate_task({"title": title, "description": desc, "category": category,
                                          "priority": priority, "due_date": due.isoformat() if due else ""})
                    now = datetime.now().isoformat(timespec="seconds")
                    item.update({"id": str(uuid.uuid4()), "created_at": now, "completed_at": ""})
                    storage.create_task(item)
                    st.success("Task added successfully.")
                    rerun()
                except ValidationError as e:
                    st.error(str(e))

    c1, c2, c3 = st.columns([2, 1, 1])
    query = c1.text_input("Search tasks", placeholder="Search title or description...")
    status = c2.selectbox("Status", ["All", "Pending", "Completed"])
    priority_filter = c3.selectbox("Priority", ["All", "High", "Medium", "Low"])
    filtered = [t for t in tasks if query.lower() in (t["title"] + " " + t.get("description", "")).lower()
                and (status == "All" or t["status"] == status)
                and (priority_filter == "All" or t["priority"] == priority_filter)]
    if not filtered:
        st.info("No tasks found. Add a task or adjust your filters.")
    for task in filtered:
        title_text = esc(task["title"])
        desc_text = esc(task.get("description") or "No description")
        done = task["status"] == "Completed"
        priority_class = "pill-high" if task["priority"] == "High" else ""
        status_pill = '<span class="pill pill-done">Completed</span>' if done else '<span class="pill">Pending</span>'
        st.markdown(f"""<div class="task-card">
          <div class="task-title">{'✓ ' if done else ''}{title_text}</div>
          <div class="task-meta">{desc_text}</div>
          <div style="margin-top:10px">{status_pill}
          <span class="pill {priority_class}">{esc(task['priority'])} priority</span>
          <span class="pill">{esc(task['category'])}</span></div>
          <div class="task-meta" style="margin-top:8px">Deadline: {esc(task.get('due_date') or 'Not set')}</div>
        </div>""", unsafe_allow_html=True)
        a, b, c = st.columns([1, 1, 5])
        if a.button("Undo" if done else "Complete", key="toggle_" + task["id"]):
            storage.toggle_task(task["id"], datetime.now().isoformat(timespec="seconds"))
            rerun()
        if b.button("Delete", key="del_" + task["id"]):
            storage.delete_task(task["id"])
            rerun()
        with c:
            with st.expander("Edit task", expanded=False):
                with st.form("edit_" + task["id"]):
                    nt = st.text_input("Title", task["title"], max_chars=100)
                    nd = st.text_area("Description", task.get("description", ""), max_chars=500)
                    cats = ["Study", "Assignment", "Personal", "Project", "Exam", "Work", "Other"]
                    nc = st.selectbox("Category", cats, index=cats.index(task["category"]) if task["category"] in cats else 6)
                    np = st.selectbox("Priority", ["Low", "Medium", "High"], index=["Low", "Medium", "High"].index(task["priority"]))
                    default_date = date.fromisoformat(task["due_date"]) if task.get("due_date") else None
                    ndate = st.date_input("Deadline", value=default_date, key="date_" + task["id"])
                    if st.form_submit_button("Save changes", type="primary"):
                        try:
                            val = validate_task({"title": nt, "description": nd, "category": nc,
                                                 "priority": np, "due_date": ndate.isoformat() if ndate else ""})
                            storage.update_task(task["id"], val)
                            st.success("Task updated.")
                            rerun()
                        except ValidationError as e:
                            st.error(str(e))

elif page == "Analytics":
    st.markdown("### Analytics")
    st.markdown('<div class="section-kicker">YOUR PRODUCTIVITY AT A GLANCE</div>', unsafe_allow_html=True)
    cols = st.columns(4)
    for col, data in zip(cols, [
        ("Completion rate", f'{report["completion_rate"]}%', "Tasks completed", "✓"),
        ("High priority", report["high_priority"], "Still pending", "!"),
        ("Completed", report["completed"], "Tasks finished", "▤"),
        ("Due in 3 days", report["due_soon"], "Upcoming deadlines", "◷"),
    ]):
        with col:
            metric_card(*data)
    st.write("")
    left, right = st.columns(2)
    with left:
        st.markdown("#### Task completion")
        pct = report["completion_rate"] if report["total"] else 0
        st.progress(pct / 100)
        st.write(f'**{report["completed"]}** completed · **{report["pending"]}** pending')
        st.markdown("#### Priority breakdown")
        total_p = max(1, sum(report["priority_breakdown"].values()))
        for label in ["High", "Medium", "Low"]:
            value = report["priority_breakdown"].get(label, 0)
            st.write(f"**{label}** · {value}")
            st.progress(value / total_p)
    with right:
        st.markdown("#### Tasks by category")
        categories = report["categories"]
        if categories:
            total_c = max(1, sum(categories.values()))
            for label, value in sorted(categories.items(), key=lambda x: (-x[1], x[0])):
                st.write(f"**{esc(label)}** · {value}")
                st.progress(value / total_c)
        else:
            st.info("Add tasks to see category analytics.")
    st.markdown("#### Executive summary")
    st.markdown(f"""<div class="task-card">You have <b>{report['total']}</b> tasks.
      <b>{report['completed']}</b> are completed ({report['completion_rate']}%).
      There are <b>{report['overdue']}</b> overdue tasks and
      <b>{report['high_priority']}</b> high-priority tasks still pending.</div>""", unsafe_allow_html=True)

else:
    st.markdown("### Import / Export")
    st.markdown('<div class="section-kicker">MOVE YOUR TASKS WITH YOU</div>', unsafe_allow_html=True)
    st.write("Download your tasks or import a CSV file. CSV columns: title, description, category, priority, due_date, status.")
    if tasks:
        csv_buffer = io.StringIO()
        writer = csv.DictWriter(csv_buffer, fieldnames=list(tasks[0].keys()))
        writer.writeheader()
        writer.writerows(tasks)
        st.download_button("⬇ Download CSV", csv_buffer.getvalue().encode("utf-8"), "campussolve_tasks.csv", "text/csv")
        st.download_button("⬇ Download JSON", json.dumps(tasks, indent=2).encode("utf-8"), "campussolve_tasks.json", "application/json")
    else:
        st.info("No tasks available to export yet.")
    uploaded = st.file_uploader("Import tasks from CSV", type=["csv"])
    if uploaded and st.button("Import CSV", type="primary"):
        try:
            content = uploaded.getvalue().decode("utf-8-sig")
            reader = csv.DictReader(io.StringIO(content))
            added, errors = 0, []
            for row_num, row in enumerate(reader, start=2):
                try:
                    item = validate_task(row)
                    now = datetime.now().isoformat(timespec="seconds")
                    item.update({"id": str(uuid.uuid4()), "created_at": now,
                                 "completed_at": now if item["status"] == "Completed" else ""})
                    storage.create_task(item)
                    added += 1
                except ValidationError as e:
                    errors.append(f"Row {row_num}: {e}")
            st.success(f"Imported {added} task(s).")
            for error in errors:
                st.warning(error)
            rerun()
        except Exception as e:
            st.error(f"Could not read CSV: {e}")
