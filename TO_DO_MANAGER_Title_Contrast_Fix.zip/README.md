# CampusSolve – Smart To-Do List Manager (Reliability Upgrade)

A responsive student productivity website built with Flask, HTML, CSS and JavaScript. This release upgrades persistence to SQLite and adds configuration, API documentation, and continuous integration.

## Requirements
- Python 3.10+
- pip

## Run on Windows (VS Code)
Open the `CampusSolve` folder in VS Code, then run:

```powershell
py -m venv venv
venv\Scripts\activate
py -m pip install -r requirements.txt
Copy-Item .env.example .env
py app.py
```

Open http://127.0.0.1:5000.

## Run on macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp .env.example .env
python app.py
```

## What's new in this release

- **SQL pagination:** search and filters run in SQLite with bounded page sizes and total-page metadata.
- **CLI compatibility:** optional terminal menu uses the same database as the web UI.
- **Alembic migrations:** versioned schema migration baseline and upgrade workflow.
- **SQLite database:** tasks are stored in `data/campussolve.db` using SQLAlchemy ORM.
- **Legacy JSON migration:** on first launch, existing `data/tasks.json` records are imported into SQLite if the database is empty. The original JSON file is retained as a backup/source.
- **Transactional writes:** database changes use transactions; SQLite WAL mode and a busy timeout improve safe concurrent access.
- **Configuration:** `.env` settings control database path, legacy JSON path, request size, host and port. Never commit `.env`.
- **API documentation:** interactive Swagger UI at `/api/docs`; machine-readable OpenAPI document at `/api/openapi.json`.
- **CI pipeline:** GitHub Actions runs the automated tests on pushes and pull requests.
- Existing task CRUD, search, filters, analytics, CSV import/export, JSON export, logging and health endpoint are retained.

## Automated tests

```powershell
py -m unittest discover -s tests -v
```

The tests cover validation, analytics, SQLite CRUD/persistence, legacy JSON migration, and Flask API routes.

## API quick reference

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/tasks` | List tasks; supports `page`, `per_page`, `q`, `status`, `category`, and `priority` query parameters |
| POST | `/api/tasks` | Create a task |
| PUT | `/api/tasks/{task_id}` | Update a task |
| PATCH | `/api/tasks/{task_id}/complete` | Toggle completion |
| DELETE | `/api/tasks/{task_id}` | Delete a task |
| GET | `/api/report` | Analytics report |
| GET | `/api/health` | Health status |
| GET | `/api/openapi.json` | OpenAPI specification |
| GET | `/api/docs` | Interactive API docs |
| GET | `/api/export/csv` | Download CSV |
| GET | `/api/export/json` | Download JSON |

## Configuration

Copy `.env.example` to `.env`. Defaults are suitable for local development.

- `DATABASE_PATH`: SQLite file path (default `data/campussolve.db`)
- `DATABASE_URL`: optional SQLAlchemy URL; when set, it overrides `DATABASE_PATH`
- `LEGACY_JSON_PATH`: old JSON file to migrate on first run
- `MAX_CONTENT_LENGTH`: maximum request/upload size in bytes
- `FLASK_HOST` / `FLASK_PORT`: local server bind address and port

## Project structure

```text
CampusSolve/
├── app.py
├── cli.py                 # Optional terminal/menu interface
├── alembic.ini
├── alembic/               # Versioned database migrations
├── analytics.py
├── storage.py
├── validation.py
├── requirements.txt
├── .env.example
├── .github/workflows/tests.yml
├── tests/
├── data/                 # SQLite DB created on first run
├── sample_data/
├── static/
└── templates/
```

## Security and deployment notes

This is a local student demo. Do not expose it publicly without adding authentication, CSRF protection, authorization, rate limiting, secure secret management, and a production WSGI server. SQLite is appropriate for a single-instance student application; a larger multi-user deployment may require PostgreSQL and a migration tool such as Alembic.

## New: SQL pagination and filters

The web dashboard now requests one page at a time. Filtering and search are applied in SQLite before rows are returned, rather than downloading every task and filtering only in the browser.

Example: `GET /api/tasks?page=2&per_page=10&q=lab&status=Pending&priority=High`

The response contains `items`, `page`, `per_page`, `total`, and `pages`. `per_page` is limited to 1–100. The no-query `/api/tasks` response remains available for backwards compatibility.

## New: command-line interface

The original terminal workflow is available as an additional interface, using the same SQLite database as the website:

```powershell
py cli.py
```

Menu options include listing, adding, completing, searching, deleting, summary analytics, and CSV export. This keeps the web dashboard while also satisfying a CLI-style demonstration requirement.

## Database schema migrations (Alembic)

For a new database, initialize and apply the migration before running the app:

```powershell
py -m alembic upgrade head
```

For an existing database created by an earlier CampusSolve release, the app creates the existing ORM tables as before; mark the baseline migration as applied once with:

```powershell
py -m alembic stamp head
```

After future model changes, create and apply a migration:

```powershell
py -m alembic revision --autogenerate -m "describe schema change"
py -m alembic upgrade head
```

Do not run `stamp head` on a brand-new empty database; use `upgrade head` instead.

## Optional Docker deployment

Install Docker Desktop, create `.env` from `.env.example`, then run from the project folder:

```powershell
docker compose up --build -d
```

Open http://localhost:5000. Stop it with `docker compose down`. Persistent SQLite data and logs are stored in Docker volumes. The container runs under a non-root user and uses Gunicorn rather than Flask's development server. The Windows/local setup uses `requirements.txt`; Docker installs the additional Linux-only server dependency from `requirements-docker.txt`.
