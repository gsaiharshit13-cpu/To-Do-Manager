# CampusSolve – Smart To-Do List Manager (Reliability Upgrade)

A responsive student productivity website built with Flask, HTML, CSS and JavaScript. This release upgrades persistence to SQLite and adds configuration, API documentation, and continuous integration.

## Requirements
- Python 3.10+
- pip

## Run on Windows (VS Code)
Open the `CampusSolve` folder in VS Code, then run:

```powershell
py -m venv venv
venv\Scripts\activate
py -m pip install -r requirements.txt
Copy-Item .env.example .env
py app.py
```

Open http://127.0.0.1:5000.

## Run on macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp .env.example .env
python app.py
```

## What's new in this release

- **SQLite database:** tasks are stored in `data/campussolve.db` using SQLAlchemy ORM.
- **Legacy JSON migration:** on first launch, existing `data/tasks.json` records are imported into SQLite if the database is empty. The original JSON file is retained as a backup/source.
- **Transactional writes:** database changes use transactions; SQLite WAL mode and a busy timeout improve safe concurrent access.
- **Configuration:** `.env` settings control database path, legacy JSON path, request size, host and port. Never commit `.env`.
- **API documentation:** interactive Swagger UI at `/api/docs`; machine-readable OpenAPI document at `/api/openapi.json`.
- **CI pipeline:** GitHub Actions runs the automated tests on pushes and pull requests.
- Existing task CRUD, search, filters, analytics, CSV import/export, JSON export, logging and health endpoint are retained.

## Automated tests

```powershell
py -m unittest discover -s tests -v
```

The tests cover validation, analytics, SQLite CRUD/persistence, legacy JSON migration, and Flask API routes.

## API quick reference

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/tasks` | List tasks |
| POST | `/api/tasks` | Create a task |
| PUT | `/api/tasks/{task_id}` | Update a task |
| PATCH | `/api/tasks/{task_id}/complete` | Toggle completion |
| DELETE | `/api/tasks/{task_id}` | Delete a task |
| GET | `/api/report` | Analytics report |
| GET | `/api/health` | Health status |
| GET | `/api/openapi.json` | OpenAPI specification |
| GET | `/api/docs` | Interactive API docs |
| GET | `/api/export/csv` | Download CSV |
| GET | `/api/export/json` | Download JSON |

## Configuration

Copy `.env.example` to `.env`. Defaults are suitable for local development.

- `DATABASE_PATH`: SQLite file path (default `data/campussolve.db`)
- `DATABASE_URL`: optional SQLAlchemy URL; when set, it overrides `DATABASE_PATH`
- `LEGACY_JSON_PATH`: old JSON file to migrate on first run
- `MAX_CONTENT_LENGTH`: maximum request/upload size in bytes
- `FLASK_HOST` / `FLASK_PORT`: local server bind address and port

## Project structure

```text
CampusSolve/
├── app.py
├── analytics.py
├── storage.py
├── validation.py
├── requirements.txt
├── .env.example
├── .github/workflows/tests.yml
├── tests/
├── data/                 # SQLite DB created on first run
├── sample_data/
├── static/
└── templates/
```

## Security and deployment notes

This is a local student demo. Do not expose it publicly without adding authentication, CSRF protection, authorization, rate limiting, secure secret management, and a production WSGI server. SQLite is appropriate for a single-instance student application; a larger multi-user deployment may require PostgreSQL and a migration tool such as Alembic.
