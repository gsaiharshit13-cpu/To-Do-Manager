"""SQLite persistence layer for CampusSolve with safe transactions and JSON migration."""
import json, logging, os, threading
from pathlib import Path
from contextlib import contextmanager
from sqlalchemy import create_engine, select, delete
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker
from sqlalchemy.types import String, Text

logger = logging.getLogger(__name__)
class StorageError(RuntimeError): pass
class Base(DeclarativeBase): pass
class Task(Base):
    __tablename__ = "tasks"
    id: Mapped[str] = mapped_column(String(64), primary_key=True)
    title: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str] = mapped_column(String(500), default="")
    category: Mapped[str] = mapped_column(String(40), default="Personal")
    priority: Mapped[str] = mapped_column(String(10), default="Medium")
    due_date: Mapped[str] = mapped_column(String(10), default="")
    status: Mapped[str] = mapped_column(String(20), default="Pending")
    created_at: Mapped[str] = mapped_column(String(32), default="")
    completed_at: Mapped[str] = mapped_column(String(32), default="")

_engine = None
_Session = None
_db_url = None
_guard = threading.RLock()

def configure_database(database_url):
    """Configure the database. Tests may pass a temporary SQLite URL."""
    global _engine, _Session, _db_url
    with _guard:
        if _engine is not None:
            _engine.dispose()
        _db_url = database_url
        connect_args = {"check_same_thread": False, "timeout": 15} if database_url.startswith("sqlite") else {}
        _engine = create_engine(database_url, future=True, connect_args=connect_args)
        _Session = sessionmaker(bind=_engine, expire_on_commit=False)
        Base.metadata.create_all(_engine)
        if database_url.startswith("sqlite"):
            with _engine.connect() as conn:
                conn.exec_driver_sql("PRAGMA journal_mode=WAL")
                conn.exec_driver_sql("PRAGMA busy_timeout=15000")
    return _engine

def _ensure():
    if _engine is None:
        configure_database(os.getenv("DATABASE_URL", "sqlite:///campussolve.db"))

def _dict(row):
    return {k: getattr(row, k) for k in ("id","title","description","category","priority","due_date","status","created_at","completed_at")}

def load_tasks(path=None):
    """Read all tasks. `path` is accepted for backwards-compatible tests/tools."""
    if path is not None:
        configure_database("sqlite:///" + str(Path(path).with_suffix(".db")).replace("\\", "/"))
    _ensure()
    with _Session() as session:
        return [_dict(x) for x in session.scalars(select(Task).order_by(Task.created_at.desc(), Task.id)).all()]

def save_tasks(tasks, path=None):
    """Replace all tasks in one transaction (useful for imports and migrations)."""
    if path is not None:
        configure_database("sqlite:///" + str(Path(path).with_suffix(".db")).replace("\\", "/"))
    _ensure()
    try:
        with _Session.begin() as session:
            session.execute(delete(Task))
            for item in tasks:
                session.add(Task(**{k: item.get(k, "") for k in ("id","title","description","category","priority","due_date","status","created_at","completed_at")}))
    except Exception as exc:
        logger.exception("SQLite task replacement failed")
        raise StorageError(f"Could not save task data: {exc}") from exc

def create_task(item):
    _ensure()
    try:
        with _Session.begin() as session:
            row = Task(**{k: item.get(k, "") for k in ("id","title","description","category","priority","due_date","status","created_at","completed_at")})
            session.add(row)
        return _dict(row)
    except Exception as exc:
        raise StorageError(f"Could not create task: {exc}") from exc

def update_task(task_id, values):
    _ensure()
    try:
        with _Session.begin() as session:
            row = session.get(Task, task_id)
            if row is None: return None
            for key, value in values.items():
                if key in {"title","description","category","priority","due_date","status","created_at","completed_at"}:
                    setattr(row, key, value)
            session.flush()
            return _dict(row)
    except Exception as exc:
        raise StorageError(f"Could not update task: {exc}") from exc

def delete_task(task_id):
    _ensure()
    try:
        with _Session.begin() as session:
            row = session.get(Task, task_id)
            if row is None: return False
            session.delete(row)
        return True
    except Exception as exc:
        raise StorageError(f"Could not delete task: {exc}") from exc

def toggle_task(task_id, completed_at):
    _ensure()
    try:
        with _Session.begin() as session:
            row = session.get(Task, task_id)
            if row is None: return None
            row.status = "Completed" if row.status != "Completed" else "Pending"
            row.completed_at = completed_at if row.status == "Completed" else ""
            session.flush()
            return _dict(row)
    except Exception as exc:
        raise StorageError(f"Could not change task status: {exc}") from exc

def migrate_json_once(json_path):
    """Import existing JSON tasks only when the database is empty; keep source file intact."""
    _ensure()
    source = Path(json_path)
    if not source.exists(): return 0
    with _Session() as session:
        if session.scalar(select(Task.id).limit(1)) is not None: return 0
    try:
        payload = json.loads(source.read_text(encoding="utf-8"))
        if not isinstance(payload, list): raise ValueError("Expected a list of tasks")
        valid = [x for x in payload if isinstance(x, dict) and x.get("id") and x.get("title")]
        if valid:
            save_tasks(valid)
            logger.info("Migrated %d task(s) from legacy JSON store", len(valid))
        return len(valid)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        logger.exception("Legacy JSON migration failed")
        raise StorageError(f"Could not migrate legacy JSON data: {exc}") from exc
