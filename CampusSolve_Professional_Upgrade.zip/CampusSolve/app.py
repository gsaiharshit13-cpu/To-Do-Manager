"""CampusSolve Flask application."""
import csv
import io
import json
import logging
import os
import uuid
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, Response, jsonify, render_template, request, send_file
from flask_swagger_ui import get_swaggerui_blueprint

from analytics import build_report
from storage import (
    StorageError, load_tasks, save_tasks, configure_database, migrate_json_once,
    create_task, update_task as db_update_task, delete_task as db_delete_task,
    toggle_task as db_toggle_task,
)
from validation import ValidationError, validate_task

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)
DATA_FILE = Path(os.getenv("LEGACY_JSON_PATH", str(DATA_DIR / "tasks.json")))
DATABASE_PATH = Path(os.getenv("DATABASE_PATH", str(DATA_DIR / "campussolve.db")))
DATABASE_URL = os.getenv("DATABASE_URL") or f"sqlite:///{DATABASE_PATH.as_posix()}"

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = int(os.getenv("MAX_CONTENT_LENGTH", str(2 * 1024 * 1024)))
app.config["JSON_SORT_KEYS"] = False
configure_database(DATABASE_URL)
migrate_json_once(DATA_FILE)


def configure_logging():
    log_dir = BASE_DIR / "logs"
    log_dir.mkdir(exist_ok=True)
    handler = RotatingFileHandler(log_dir / "campussolve.log", maxBytes=500_000, backupCount=3, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    handler.setLevel(logging.INFO)
    if not any(isinstance(h, RotatingFileHandler) for h in app.logger.handlers):
        app.logger.addHandler(handler)
    app.logger.setLevel(logging.INFO)


configure_logging()


def _load():
    return load_tasks()


def _save(tasks):
    save_tasks(tasks)


def _json_payload():
    payload = request.get_json(silent=True)
    if not isinstance(payload, dict):
        raise ValidationError("Send task details as a valid JSON object.")
    return payload


@app.errorhandler(StorageError)
def handle_storage_error(error):
    app.logger.error("Storage operation failed: %s", error)
    return jsonify({"error": str(error)}), 500


@app.errorhandler(413)
def file_too_large(_error):
    return jsonify({"error": "The uploaded file is too large. Maximum size is 2 MB."}), 413


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/api/tasks")
def get_tasks():
    return jsonify(_load())


@app.post("/api/tasks")
def add_task():
    try:
        task = validate_task(_json_payload())
        now = datetime.now().isoformat(timespec="seconds")
        task.update({"id": str(uuid.uuid4()), "created_at": now,
                     "completed_at": now if task["status"] == "Completed" else ""})
        created = create_task(task)
        app.logger.info("Task created: %s", task["id"])
        return jsonify(created), 201
    except ValidationError as error:
        return jsonify({"error": str(error)}), 400


@app.put("/api/tasks/<task_id>")
def update_task(task_id):
    try:
        incoming = validate_task(_json_payload())
        existing = next((t for t in _load() if t["id"] == task_id), None)
        if existing is None:
            return jsonify({"error": "Task not found."}), 404
        if incoming["status"] == "Completed" and existing.get("status") != "Completed":
            incoming["completed_at"] = datetime.now().isoformat(timespec="seconds")
        elif incoming["status"] == "Pending":
            incoming["completed_at"] = ""
        updated = db_update_task(task_id, incoming)
        app.logger.info("Task updated: %s", task_id)
        return jsonify(updated)
    except ValidationError as error:
        return jsonify({"error": str(error)}), 400


@app.patch("/api/tasks/<task_id>/complete")
def complete_task(task_id):
    updated = db_toggle_task(task_id, datetime.now().isoformat(timespec="seconds"))
    if updated is None:
        return jsonify({"error": "Task not found."}), 404
    app.logger.info("Task status changed: %s -> %s", task_id, updated["status"])
    return jsonify(updated)


@app.delete("/api/tasks/<task_id>")
def delete_task(task_id):
    if not db_delete_task(task_id):
        return jsonify({"error": "Task not found."}), 404
    app.logger.info("Task deleted: %s", task_id)
    return jsonify({"success": True})


@app.get("/api/export/<kind>")
def export_tasks(kind):
    tasks = _load()
    if kind == "json":
        return Response(json.dumps(tasks, indent=2, ensure_ascii=False), mimetype="application/json",
                        headers={"Content-Disposition": "attachment; filename=campussolve_tasks.json"})
    if kind == "csv":
        output = io.StringIO(newline="")
        fields = ["id", "title", "description", "category", "priority", "due_date", "status", "created_at", "completed_at"]
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        writer.writerows(tasks)
        return Response(output.getvalue(), mimetype="text/csv",
                        headers={"Content-Disposition": "attachment; filename=campussolve_tasks.csv"})
    return jsonify({"error": "Unsupported export format."}), 400


@app.post("/api/import")
def import_csv():
    if "file" not in request.files:
        return jsonify({"error": "Choose a CSV file first."}), 400
    file = request.files["file"]
    if not file.filename or not file.filename.lower().endswith(".csv"):
        return jsonify({"error": "Only .csv files are supported."}), 400
    try:
        content = file.stream.read().decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(content))
        if not reader.fieldnames or "title" not in reader.fieldnames:
            return jsonify({"error": "CSV must contain a title column."}), 400
        tasks, errors, added = _load(), [], 0
        for row_num, row in enumerate(reader, start=2):
            if row_num > 1001:
                errors.append({"row": row_num, "error": "Import limit is 1,000 rows per file."})
                break
            try:
                item = validate_task(row)
                now = datetime.now().isoformat(timespec="seconds")
                item.update({"id": str(uuid.uuid4()), "created_at": now,
                             "completed_at": now if item["status"] == "Completed" else ""})
                tasks.insert(0, item)
                added += 1
            except ValidationError as error:
                errors.append({"row": row_num, "error": str(error)})
        _save(tasks)
        app.logger.info("CSV import completed: %d added, %d invalid rows", added, len(errors))
        return jsonify({"added": added, "errors": errors})
    except UnicodeDecodeError:
        return jsonify({"error": "CSV must be UTF-8 encoded."}), 400
    except csv.Error as error:
        app.logger.warning("CSV import parsing failed: %s", error)
        return jsonify({"error": "The CSV file could not be parsed."}), 400


@app.get("/api/report")
def report():
    return jsonify(build_report(_load()))


@app.get("/api/openapi.json")
def openapi_spec():
    return jsonify({
        "openapi": "3.0.3",
        "info": {"title": "CampusSolve API", "version": "2.0.0", "description": "Task management API for the CampusSolve student productivity app."},
        "servers": [{"url": "http://127.0.0.1:5000"}],
        "paths": {
            "/api/tasks": {
                "get": {"summary": "List all tasks", "responses": {"200": {"description": "Task list"}}},
                "post": {"summary": "Create a task", "requestBody": {"required": True, "content": {"application/json": {"schema": {"type": "object", "required": ["title"], "properties": {"title": {"type": "string"}, "description": {"type": "string"}, "category": {"type": "string"}, "priority": {"type": "string", "enum": ["Low", "Medium", "High"]}, "due_date": {"type": "string", "format": "date"}}}}}}, "responses": {"201": {"description": "Created"}, "400": {"description": "Validation error"}}}
            },
            "/api/tasks/{task_id}": {
                "put": {"summary": "Update a task", "parameters": [{"name": "task_id", "in": "path", "required": True, "schema": {"type": "string"}}], "responses": {"200": {"description": "Updated"}, "404": {"description": "Not found"}}},
                "delete": {"summary": "Delete a task", "parameters": [{"name": "task_id", "in": "path", "required": True, "schema": {"type": "string"}}], "responses": {"200": {"description": "Deleted"}, "404": {"description": "Not found"}}}
            },
            "/api/tasks/{task_id}/complete": {"patch": {"summary": "Toggle task completion", "parameters": [{"name": "task_id", "in": "path", "required": True, "schema": {"type": "string"}}], "responses": {"200": {"description": "Updated status"}}}},
            "/api/report": {"get": {"summary": "Get task analytics", "responses": {"200": {"description": "Analytics report"}}}},
            "/api/health": {"get": {"summary": "Health check", "responses": {"200": {"description": "Service status"}}}}
        }
    })


SWAGGER_URL = "/api/docs"
swagger_bp = get_swaggerui_blueprint(SWAGGER_URL, "/api/openapi.json", config={"app_name": "CampusSolve API"})
app.register_blueprint(swagger_bp, url_prefix=SWAGGER_URL)


@app.get("/api/health")
def health():
    """Simple operational status endpoint for demo and troubleshooting."""
    return jsonify({"status": "ok", "storage": "sqlite", "task_count": len(_load()),
                    "database": str(DATABASE_PATH.name), "log_file": "logs/campussolve.log"})


if __name__ == "__main__":
    # Debug mode is opt-in; do not expose the interactive debugger by default.
    app.run(host=os.getenv("FLASK_HOST", "127.0.0.1"),
            port=int(os.getenv("FLASK_PORT", "5000")), debug=False)
