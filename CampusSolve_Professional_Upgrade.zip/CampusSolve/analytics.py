"""Task analytics and productivity summaries."""
from datetime import date, timedelta


def build_report(tasks, today=None):
    today = today or date.today()
    today_text = today.isoformat()
    total = len(tasks)
    completed = sum(t.get("status") == "Completed" for t in tasks)
    pending = total - completed
    overdue = sum(t.get("status") != "Completed" and t.get("due_date") and t["due_date"] < today_text for t in tasks)
    high = sum(t.get("priority") == "High" and t.get("status") != "Completed" for t in tasks)
    due_soon_limit = (today + timedelta(days=3)).isoformat()
    due_soon = sum(t.get("status") != "Completed" and today_text <= t.get("due_date", "") <= due_soon_limit for t in tasks)
    categories = {}
    priorities = {"High": 0, "Medium": 0, "Low": 0}
    for task in tasks:
        category = task.get("category", "Other")
        categories[category] = categories.get(category, 0) + 1
        priority = task.get("priority", "Medium")
        if priority in priorities:
            priorities[priority] += 1
    rate = round(completed / total * 100) if total else 0
    return {
        "total": total,
        "completed": completed,
        "pending": pending,
        "overdue": overdue,
        "high_priority": high,
        "completion_rate": rate,
        "categories": categories,
        "due_soon": due_soon,
        "priority_breakdown": priorities,
        "productivity_score": rate,
    }
