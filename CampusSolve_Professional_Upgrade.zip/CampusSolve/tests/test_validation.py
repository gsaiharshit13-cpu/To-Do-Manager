import unittest
from validation import ValidationError, validate_task


class TaskValidationTests(unittest.TestCase):
    def test_valid_task_is_normalized(self):
        task = validate_task({"title": "  Revise Python ", "priority": "high", "due_date": "2026-12-01"})
        self.assertEqual(task["title"], "Revise Python")
        self.assertEqual(task["priority"], "High")
        self.assertEqual(task["status"], "Pending")

    def test_empty_title_is_rejected(self):
        with self.assertRaisesRegex(ValidationError, "Title is required"):
            validate_task({"title": "   "})

    def test_invalid_priority_is_rejected(self):
        with self.assertRaisesRegex(ValidationError, "Priority must"):
            validate_task({"title": "Task", "priority": "Urgent"})

    def test_invalid_date_is_rejected(self):
        with self.assertRaisesRegex(ValidationError, "valid date"):
            validate_task({"title": "Task", "due_date": "31-12-2026"})

    def test_title_length_is_limited(self):
        with self.assertRaisesRegex(ValidationError, "100 characters"):
            validate_task({"title": "x" * 101})

    def test_non_object_payload_is_rejected(self):
        with self.assertRaises(ValidationError):
            validate_task(["not", "an", "object"])


if __name__ == "__main__":
    unittest.main()
