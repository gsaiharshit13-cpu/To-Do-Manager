import unittest
from datetime import date
from analytics import build_report


class AnalyticsTests(unittest.TestCase):
    def test_report_counts_and_productivity_score(self):
        tasks = [
            {"status": "Completed", "priority": "High", "category": "Study", "due_date": ""},
            {"status": "Pending", "priority": "High", "category": "Study", "due_date": "2026-12-03"},
            {"status": "Pending", "priority": "Low", "category": "Personal", "due_date": "2026-11-20"},
        ]
        report = build_report(tasks, today=date(2026, 12, 1))
        self.assertEqual(report["total"], 3)
        self.assertEqual(report["completed"], 1)
        self.assertEqual(report["pending"], 2)
        self.assertEqual(report["overdue"], 1)
        self.assertEqual(report["due_soon"], 1)
        self.assertEqual(report["productivity_score"], 33)
        self.assertEqual(report["categories"]["Study"], 2)

    def test_empty_report_is_safe(self):
        report = build_report([], today=date(2026, 1, 1))
        self.assertEqual(report["completion_rate"], 0)
        self.assertEqual(report["total"], 0)


if __name__ == "__main__":
    unittest.main()
