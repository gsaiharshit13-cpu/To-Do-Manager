import json
import tempfile
import unittest
from pathlib import Path
from storage import configure_database, load_tasks, save_tasks, create_task, update_task, delete_task, migrate_json_once

class StorageTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db = Path(self.temp_dir.name) / "tasks.db"
        configure_database(f"sqlite:///{self.db.as_posix()}")

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_save_and_load_round_trip(self):
        tasks = [{"id":"1","title":"Test task","status":"Pending","description":"","category":"Study","priority":"High","due_date":"","created_at":"","completed_at":""}]
        save_tasks(tasks)
        self.assertEqual(load_tasks(), tasks)

    def test_create_update_delete(self):
        item = {"id":"2","title":"Created","status":"Pending"}
        create_task(item)
        updated = update_task("2", {"title":"Updated"})
        self.assertEqual(updated["title"], "Updated")
        self.assertTrue(delete_task("2"))
        self.assertFalse(delete_task("2"))
        self.assertEqual(load_tasks(), [])

    def test_json_migration_keeps_original(self):
        legacy = Path(self.temp_dir.name) / "legacy.json"
        legacy.write_text(json.dumps([{"id":"old","title":"Legacy task","status":"Pending"}]), encoding="utf-8")
        self.assertEqual(migrate_json_once(legacy), 1)
        self.assertEqual(load_tasks()[0]["title"], "Legacy task")
        self.assertTrue(legacy.exists())

if __name__ == "__main__":
    unittest.main()
