"""Flask route integration tests (run after installing requirements.txt)."""
import tempfile
import unittest
from pathlib import Path

try:
    import app as campus_app
except ModuleNotFoundError as exc:
    if exc.name == "flask":
        raise unittest.SkipTest("Install Flask with: python -m pip install -r requirements.txt")
    raise


class TaskApiTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.original_db_path = campus_app.DATABASE_PATH
        campus_app.DATABASE_PATH = Path(self.temp_dir.name) / "test.db"
        campus_app.configure_database(f"sqlite:///{campus_app.DATABASE_PATH.as_posix()}")
        campus_app.app.config.update(TESTING=True)
        self.client = campus_app.app.test_client()

    def tearDown(self):
        campus_app.DATABASE_PATH = self.original_db_path
        self.temp_dir.cleanup()

    def test_create_complete_and_delete_task(self):
        response = self.client.post("/api/tasks", json={"title": "Integration test task", "priority": "High"})
        self.assertEqual(response.status_code, 201)
        task_id = response.get_json()["id"]

        response = self.client.patch(f"/api/tasks/{task_id}/complete")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["status"], "Completed")

        response = self.client.delete(f"/api/tasks/{task_id}")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.client.get("/api/tasks").get_json(), [])

    def test_invalid_task_returns_clear_client_error(self):
        response = self.client.post("/api/tasks", json={"title": ""})
        self.assertEqual(response.status_code, 400)
        self.assertIn("Title is required", response.get_json()["error"])

    def test_health_endpoint_reports_ok(self):
        response = self.client.get("/api/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["status"], "ok")


if __name__ == "__main__":
    unittest.main()
