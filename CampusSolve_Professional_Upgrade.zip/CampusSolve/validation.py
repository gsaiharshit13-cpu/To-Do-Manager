"""Input validation helpers for CampusSolve."""
from datetime import datetime


class ValidationError(ValueError):
    """Raised when user-supplied task data is invalid."""


def _text(value, field, limit, required=True):
    if value is None:
        value = ""
    if not isinstance(value, (str, int, float)):
        raise ValidationError(f"{field} must be text.")
    value = str(value).strip()
    if required and not value:
        raise ValidationError(f"{field} is required.")
    if len(value) > limit:
        raise ValidationError(f"{field} must be {limit} characters or fewer.")
    return value


def validate_task(payload):
    if not isinstance(payload, dict):
        raise ValidationError("Task data must be a JSON object.")

    title = _text(payload.get("title"), "Title", 100)
    description = _text(payload.get("description", ""), "Description", 500, required=False)
    category = _text(payload.get("category", "Personal"), "Category", 40)
    priority = _text(payload.get("priority", "Medium"), "Priority", 10).title()
    if priority not in ("Low", "Medium", "High"):
        raise ValidationError("Priority must be Low, Medium, or High.")

    due = _text(payload.get("due_date", ""), "Deadline", 10, required=False)
    if due:
        try:
            datetime.strptime(due, "%Y-%m-%d")
        except ValueError as exc:
            raise ValidationError("Deadline must be a valid date in YYYY-MM-DD format.") from exc

    status = _text(payload.get("status", "Pending"), "Status", 20).title()
    if status not in ("Pending", "Completed"):
        raise ValidationError("Status must be Pending or Completed.")

    return {
        "title": title,
        "description": description,
        "category": category,
        "priority": priority,
        "due_date": due,
        "status": status,
    }
